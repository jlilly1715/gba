eDKit
=====

Level editor for Donkey Kong '94 for Classic Gameboy

=====

Just run qmake && make. This has only been tested on Linux (Kubuntu 12.04 x64)

The application expects "base.gb" in its directory.
